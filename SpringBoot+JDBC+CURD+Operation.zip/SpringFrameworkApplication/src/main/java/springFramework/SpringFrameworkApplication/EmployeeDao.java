package springFramework.SpringFrameworkApplication;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class EmployeeDao {

	static ArrayList<Employee> list = new ArrayList<Employee>();

	// Connection method
	public static Connection connection() throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "root");
		return conn;
	}

	// GetMapping Method using JDBC
	public static ArrayList<Employee> getdata() throws Exception {
		Connection conn = connection();
		Statement statement = conn.createStatement();
		String query = "SELECT * FROM employee";
		ResultSet resultSet = statement.executeQuery(query);

		while (resultSet.next()) {
			int eid = resultSet.getInt(1);
			String ename = resultSet.getString(2);
			int salary = resultSet.getInt(3);
			String location = resultSet.getString(4);
			Employee emp = new Employee(eid, ename, salary, location);

			list.add(emp);
		}

		return list;
	}

	// PostMapping Method using JDBC
	public static void addEmployee(Employee employee) throws Exception {

		Connection conn = connection();
		String query = "INSERT INTO employee VALUES(?,?,?,?)";
		PreparedStatement ps = conn.prepareStatement(query);

		ps.setInt(1, employee.eid);
		ps.setString(2, employee.ename);
		ps.setInt(3, employee.salary);
		ps.setString(4, employee.location);
		ps.executeUpdate();
		ps.close();
	}

	// UpdateMapping Method using JDBC
	public static void updateEmployee(int user_id, Employee emp) throws Exception {

		Connection conn = connection();

		String query = "UPDATE employee SET ename=?,salary=?,location=? WHERE eid=?";

		PreparedStatement ps = conn.prepareStatement(query);

		ArrayList<Employee> list_of_emp = getdata();
		for (Employee employee : list_of_emp) {

			if (user_id == employee.eid) {

				ps.setString(1, emp.ename);
				ps.setInt(2, emp.salary);
				ps.setString(3, emp.location);
				ps.setInt(4, emp.eid);

			}
		}

		ps.executeUpdate();
		ps.close();
		System.err.println("Done................");
	}

	// DeleteMapping Method using JDBC
	public static int deleteEmployeeRecord(int userId) throws Exception {

		Connection conn = connection();
		Statement statement = conn.createStatement();
		String query = "DELETE FROM employee WHERE eid=?";
		PreparedStatement ps = conn.prepareStatement(query);

		ArrayList<Employee> list_of_emp = getdata();
		for (Employee emp : list_of_emp) {
			if (userId == emp.eid) {
				ps.setInt(1, userId);
			}
		}
		int k = ps.executeUpdate();
		ps.close();
		return k;

	}
}
