package springFramework.SpringFrameworkApplication;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("employee")
public class EmployeeController_JDBC {

	static ArrayList<Employee> list = new ArrayList<Employee>();

	public static Connection connection() throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "root");
		return conn;
	}

	@GetMapping("get_all_employee")
	public static ArrayList<Employee> getdata() throws Exception {

		ArrayList<Employee> arrayList = EmployeeDao.getdata();
		return arrayList;
	}

	@PostMapping("add_employee_data")
	public String addemployee(@RequestBody Employee employee) throws Exception {

		EmployeeDao.addEmployee(employee);
		return "All record inserted successfully";
	}

	@PutMapping("updatedata/{user_id}")
	public String updateemployee(@PathVariable int user_id, @RequestBody Employee emp) throws Exception {

		EmployeeDao.updateEmployee(user_id, emp);

		return "All record update succesfully";
	}

	@DeleteMapping("deleterecord/{userId}")
	public String delete_employee_record(@PathVariable int userId) throws Exception {

		int k = EmployeeDao.deleteEmployeeRecord(userId);
		return k + " record deleted succesfully";

	}

}
